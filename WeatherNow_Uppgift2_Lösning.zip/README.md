# WeatherNow AI-baserad Mejlassistent

Denna lösning är framtagen för att automatisera hanteringen av kundmejl för WeatherNow. Systemet består av en .NET-backend som hanterar affärslogik och en n8n-automation som använder AI för att generera svarsförslag.

## Innehåll
- `backend/`: C#-källkod för .NET-tjänsten.
- `automation/`: Exportfil (JSON) för n8n-workflow.
- `docs/`: Säkerhetsanalys och kritisk reflektion (PDF-underlag).

## Hur man kör lösningen

### 1. .NET Backend
Backend-koden är skriven i C# och simulerar affärslogiken för mejlprocessering.
- Öppna filerna i en IDE (t.ex. Visual Studio eller Cursor).
- Skapa ett nytt Console Application-projekt.
- Lägg till `EmailService.cs` och `Program.cs`.
- Kör applikationen för att se hur olika mejl kategoriseras och får svarsförslag.

### 2. n8n Automation
Automationen tar emot mejl via en Webhook och använder en LLM för att generera svar.
- Importera filen `weathernow_workflow.json` i din n8n-instans.
- Konfigurera dina API-nycklar för OpenAI.
- Webhook-noden lyssnar på `POST`-anrop till `/weathernow-email`.

## Lösningens syfte
Lösningen minskar svarstiderna genom att automatiskt förbereda svar som personalen bara behöver granska och godkänna, vilket direkt adresserar de problem med stress och missnöjda kunder som identifierades i beslutsunderlaget.
