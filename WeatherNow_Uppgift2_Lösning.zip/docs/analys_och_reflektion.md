# Säkerhetsanalys och Kritisk Reflektion - WeatherNow AI

## Del 3: Säkerhetsanalys (OWASP LLM Top 10)

Vi har analyserat WeatherNow-lösningen utifrån OWASP:s topplista för LLM-risker. Nedan följer de mest relevanta riskerna för vår mejlhanteringstjänst.

| Risk | Beskrivning i WeatherNow-caset | Hantering / Mitigation |
| :--- | :--- | :--- |
| **LLM01: Prompt Injection** | En kund kan skriva instruktioner i ett mejl för att lura AI:n att ge ut känslig info eller ändra sitt beteende. | Vi använder strikta system-prompter och låter aldrig AI:n skicka mejl direkt utan mänsklig granskning. |
| **LLM02: Insecure Output Handling** | AI:n kan generera skadlig kod eller länkar i svarsförslaget som personalen råkar klicka på. | All output från AI:n behandlas som oformaterad text och granskas manuellt av personalen i ett säkert gränssnitt. |
| **LLM06: Sensitive Information Disclosure** | AI:n kan råka inkludera en annan kunds data i ett svarsförslag om den tränats på intern data. | Vi använder en "Zero-retention"-policy hos API-leverantören och maskerar känslig data innan den skickas till AI:n. |
| **LLM09: Overreliance** | Personalen litar för mycket på AI:ns förslag och slutar kontrollera fakta, vilket leder till felaktiga svar. | Utbildning av personalen där vi betonar att AI:n endast är ett stöd och att det juridiska ansvaret ligger hos människan. |

## Del 4: Kritisk reflektion

### Vad fungerade bra?
Implementeringen av en n8n-automation i kombination med en .NET-backend visade sig vara mycket effektiv. Genom att separera affärslogiken (backend) från integrationslogiken (automation) skapade vi ett system som är både skalbart och lätt att underhålla. AI:n var extremt duktig på att förstå tonläget i kundmejlen och anpassa svarsförslagen därefter.

### Vad fungerade mindre bra?
En utmaning var att hantera mycket korta eller otydliga mejl. Där tenderade AI:n att gissa (hallucinera) vad kunden ville, vilket skapade svarsförslag som inte var relevanta. Här var det tydligt att AI:n behöver mer kontext eller tydligare instruktioner för att hantera osäkerhet.

### När var AI rätt verktyg?
AI var det perfekta verktyget för att snabbt läsa igenom stora mängder text och sammanfatta kärnan i ett ärende. Att manuellt kategorisera 1000 mejl tar timmar, men för AI:n tar det sekunder. Det är ett utmärkt verktyg för att skapa utkast och minska "den vita sidans skräck" för personalen.

### Vad skulle göras annorlunda?
Om jag skulle fortsätta projektet skulle jag bygga in en mer avancerad maskering av personuppgifter (PII) innan data skickas till AI-modellen för att ytterligare stärka integritetsskyddet. Jag skulle även implementera en feedback-loop där personalen kan betygsätta AI-förslagen för att kontinuerligt förbättra systemet.
